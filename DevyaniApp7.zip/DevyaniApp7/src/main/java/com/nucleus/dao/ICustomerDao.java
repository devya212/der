package com.nucleus.dao;

import java.util.List;

import com.nucleus.model.Customer;
import com.nucleus.model.User;

public interface ICustomerDao {
public void saveCustomer(Customer customer);
public void delete(Customer customer);
public void update(Customer customer);
public List<Customer> selectAll();
public void saveUser(User user);
}
