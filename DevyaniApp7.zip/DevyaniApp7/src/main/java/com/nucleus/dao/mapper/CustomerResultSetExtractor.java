package com.nucleus.dao.mapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ResultSetExtractor;

import com.nucleus.model.Customer;

public class CustomerResultSetExtractor implements ResultSetExtractor{

	@Override
	public Object extractData(ResultSet rs) throws SQLException, DataAccessException {
		 Customer customer = new Customer();
	       customer.setCustomerid(rs.getInt(1));
	        customer.setCustname(rs.getString(2));
	        return customer;
	}

}
